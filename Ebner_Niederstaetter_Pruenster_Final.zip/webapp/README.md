# Alpine Parking Webapp

Simple frontend for checking out how many parking spaces are left in the parking and also to find your car via your number plate. There is also a "backend" for the survailance cameras to upload their pictures. To start the server type:

```sh
npm i
npm start
```

Thats it!

## Links

- Frontend running at: http://localhost:8080
- Backend running at: http://localhost:8080/backend